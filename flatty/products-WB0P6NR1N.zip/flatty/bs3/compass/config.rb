images_dir = 'assets/images'
fonts_dir = 'assets/fonts'
relative_assets = true